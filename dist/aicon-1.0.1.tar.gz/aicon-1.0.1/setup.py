from setuptools import setup

setup (name = 'aicon',
       version = '1.0.1',
       description = 'Initial release with only Style Transfer',
       packages = ['aicon'],
       author = 'Dinesh Kumar Gnanasekaran',
       author_email = 'dinesh.gna111@gmail.com',
       zip_safe = False,
       include_package_data=True)