from .StyleTransfer import StyleTransfer

class styletx:
    def __version__():
        print('1.0.1')

if __name__ == '__main__':
    styleyx = styletx()
